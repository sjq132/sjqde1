"""
MVTec AD 像素级标注（PNG mask）→ YOLO 格式检测框（txt）
每个 mask 中提取最大外接矩形作为 bounding box

路径说明：脚本会自动向上查找项目根目录（包含 data/raw 的目录），
因此无论从哪个目录运行，只要处于项目内即可，无需使用 ../../ 这种脆弱相对路径。
"""

import sys
from pathlib import Path
import cv2
import numpy as np


def find_project_root(start: Path) -> Path:
    """从当前文件所在目录向上查找项目根目录。"""
    cur = start.resolve()
    for parent in [cur, *cur.parents]:
        if (parent / "data" / "raw").exists() or (parent / "data").exists():
            return parent
    return cur


# ======== 配置 ========
IMG_SIZE = 640

CLASSES = sorted([
    "bottle", "cable", "capsule", "carpet", "grid", "hazelnut",
    "leather", "metal_nut", "pill", "screw", "tile", "toothbrush",
    "transistor", "wood", "zipper"
])
CLASS2ID = {name: idx for idx, name in enumerate(CLASSES)}


def mask_to_yolo_bbox(mask_path: Path):
    """从二值 mask 中提取最小外接矩形，转为 YOLO 归一化坐标。"""
    mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        return None
    _, bin_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(bin_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    cnt = max(contours, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(cnt)

    cx = (x + w / 2.0) / IMG_SIZE
    cy = (y + h / 2.0) / IMG_SIZE
    nw = w / IMG_SIZE
    nh = h / IMG_SIZE

    # 越界保护
    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    nw = min(max(nw, 0.0), 1.0)
    nh = min(max(nh, 0.0), 1.0)
    return cx, cy, nw, nh


def get_category_from_path(rel_path: Path) -> str:
    """从路径中解析类别名（mvtec 结构：<class>/.../ground_truth/...）。

    策略：优先取 ground_truth 上一级；若该级不在 CLASS2ID 中（如子缺陷类型名），
    则向上回溯到第一层目录（即类别目录）。兜底返回 "unknown"。
    """
    parts = rel_path.parts
    # 找 ground_truth 位置
    gt_idx = None
    for i, p in enumerate(parts):
        if p == "ground_truth":
            gt_idx = i
            break
    if gt_idx is not None and gt_idx > 0:
        candidate = parts[gt_idx - 1]
        if candidate in CLASS2ID:
            return candidate
    # 回溯到第一层（类别目录）
    if parts and parts[0] in CLASS2ID:
        return parts[0]
    return parts[0] if parts else "unknown"


def main():
    script_dir = Path(__file__).parent.resolve()
    project_root = script_dir.parent.parent
    if not (project_root / "data").exists():
        project_root = find_project_root(script_dir)

    src = project_root / "data" / "raw" / "mvtec_ad"
    dst = project_root / "data" / "processed" / "labels"

    print(f"[INFO] 项目根目录: {project_root}")
    print(f"[INFO] 数据源    : {src}")
    print(f"[INFO] 输出目录  : {dst}")

    if not src.exists():
        print(f"[ERROR] 未找到原始数据目录: {src}")
        print("        请先按 data/README.md 下载并解压 MVTec AD 到 data/raw/mvtec_ad/")
        sys.exit(1)

    if dst.exists():
        for f in dst.rglob("*.txt"):
            f.unlink()
    dst.mkdir(parents=True, exist_ok=True)

    converted = 0
    for mask_path in sorted(src.rglob("*.png")):
        # 只处理 ground_truth 下的标注
        if "ground_truth" not in mask_path.parts:
            continue

        bbox = mask_to_yolo_bbox(mask_path)
        rel = mask_path.relative_to(src)
        category = get_category_from_path(rel)

        if bbox is None or category not in CLASS2ID:
            continue

        out_txt = dst / rel.with_suffix(".txt")
        out_txt.parent.mkdir(parents=True, exist_ok=True)
        cx, cy, nw, nh = bbox
        cls_id = CLASS2ID[category]
        with open(out_txt, "w") as f:
            f.write(f"{cls_id} {cx:.6f} {cy:.6f} {nw:.6f} {nh:.6f}\n")
        converted += 1

    print(f"[DONE] 标注转换完成：共生成 {converted} 个 YOLO 标签文件 → {dst}")


if __name__ == "__main__":
    main()
